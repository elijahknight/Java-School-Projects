package basketballteam;

import javax.swing.JOptionPane;

public class BasketballTeam {

    public static void main(String[] args) {
        //Elijah Knight, CSC 112, Spring 2017, Program 1 - Basketball Team
//HELP from Kyle on Search Function        
//Initialize variables
        Player player = new Player();
        Team team = new Team();
        String mainMenu = null;
        String cont = "Y";
        String playerName = null;
        String playerTeam;
        int playerNum = 0;
        int playerPoints;
        int find;
        //while loop
        while (cont.equalsIgnoreCase("Y")) {
           //main menu
            mainMenu = JOptionPane.showInputDialog("(A)dd a player to the database"
                    + "\n(R)emove a player"
                    + "\n(S)earch for a player"
                    + "\n(D)isplay all players");
           //to add player
            if (mainMenu.equalsIgnoreCase("A")) {
                playerName = JOptionPane.showInputDialog("Enter Player Name");
                playerTeam = JOptionPane.showInputDialog("Enter Men or Women");
                playerNum = Integer.parseInt(JOptionPane.showInputDialog("Enter Number"));
                playerPoints = Integer.parseInt(JOptionPane.showInputDialog("Enter Points"));
                team.addPlayer(playerName, playerTeam, playerNum, playerPoints);
                
                //to remove player
            }
            if (mainMenu.equalsIgnoreCase("R")) {
                 playerNum = Integer.parseInt(JOptionPane.showInputDialog("Enter Number to be Removed"));
                team.deletePlayer(playerNum);
            }
//to display players
            if (mainMenu.equalsIgnoreCase("D")) {
                JOptionPane.showMessageDialog(null, team.displayPlayers());
            }//to search a player
            if (mainMenu.equalsIgnoreCase("s")){
                 find = Integer.parseInt(JOptionPane.showInputDialog("Enter player name and number (Knight3)"));
                 JOptionPane.showMessageDialog(null, team.PlayerSearch(find));
                
            }//to quit
            if (mainMenu.equalsIgnoreCase("q")) {
                cont = "q";

            }
        }

    }
}
