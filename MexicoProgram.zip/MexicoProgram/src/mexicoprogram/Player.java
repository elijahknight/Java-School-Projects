package mexicoprogram;

import javax.swing.JOptionPane;

public class Player {

    private String name;
    private int score = 0;
    private int lives = 5;

    public Player(String n) {
        name = n;
    }

    public void setName1() {
        name = JOptionPane.showInputDialog(null, "Enter player's name");

    }

    public String getName1() {
        return name;
    }

    public int getLives() {
        return lives;

    }

    public int getScore() {
        return score;

    }

    public void loseLife() {
        lives += -1;

    }

    public void addScore(int s) {
        score += s;

    }

    public void restartGame() {
        score = 0;
        lives = 5;
    }

    public void restartRound() {
        score = 0;
    }
}
