package mexicoprogram;

import java.util.Random;

public class Dice {

    private int die1;

    public Dice() {
        roll();
    }

    public int roll() {
        die1 = (int) (Math.random() * 6) + 1;
        return die1;
    }


}
