package battleship;

import javax.swing.JOptionPane;

public class Battleship {

    public static void main(String[] args) {
        // Elijah Knight, CSC 112, Spring 2017, Program #2, Destroy the Destroyer

        gameBoard board = new gameBoard();
        //constructor methods
        board.setupBoard();
        board.placeShip();
        //set variables
        int x = 0;
        int y = 0;
        String cont = "Y";

        //intro message
        JOptionPane.showMessageDialog(null, "Welcome to 'Destroy the Destroyer'. This game is similar to the "
                + "\noriginal battleship game but with only one ship. Have Fun! Written by Elijah Knight.");

        //while loop
        while (cont.equalsIgnoreCase("Y")) {
            while (board.getStrikes() < 4 && cont.equalsIgnoreCase("Y")) {
                //get placement for shot from user
                x = Integer.parseInt(JOptionPane.showInputDialog(board.showBoard() + "\nChoose an x value:"));
                y = Integer.parseInt(JOptionPane.showInputDialog(board.showBoard() + "\nChoose a y value:"));
                //shoot 
                board.shoot(x, y);
                //show board and ask if user wants to continue 
                JOptionPane.showMessageDialog(null, board.showBoard());
                cont = JOptionPane.showInputDialog("Continue? (y) or (n)");
            }
            //see if user has won or not yet
            if (board.getStrikes() == 4) {
                JOptionPane.showMessageDialog(null, "You're the winner!!! Your total shots in that game was " + board.getAttempts());
            }
            //ask user if they would like to play again and restart if yes
            cont = JOptionPane.showInputDialog("Play again? (y) or (n)");
            if (cont.equalsIgnoreCase("Y")) {
                board.getStats();
                board.setupBoard();
                board.placeShip();

            } else {
                //show statistics
                JOptionPane.showMessageDialog(null, "Your total attempts were " + board.getAttempts()
                        + "\nYour maximum number of attempts was " + board.getMaxAttempts()
                        + "\nYour minimum number of attempts was " + board.getMinAttempts()
                        + "\nYour average number of attempts was " + board.getAvgAttempts());

            }

        }

        //exit message
        JOptionPane.showMessageDialog(null, "Hope you had fun... Thanks for playing!");

    }}



